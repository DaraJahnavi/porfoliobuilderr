from django.contrib import admin
from home.models import userdetail,analytic

# Register your models here.

admin.site.register(userdetail)
admin.site.register(analytic)